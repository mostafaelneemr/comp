@extends('layouts.app')

@section('content')
    <form class="form-horizontal" action="{{ route('cities.update',$city->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PATCH')
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class="col-lg-6 col-lg-offset-3">
            <div class="panel">
          
                <div class="panel-body">
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="name_ar">{{translate('Name Ar')}}</label>
                        <div class="col-sm-10">
                            <input type="text" placeholder="{{translate('Name Ar')}}" id="name_ar" name="name_ar"
                                   class="form-control" value="{{$city->name_ar}}" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="name">{{translate('Name En')}}</label>
                        <div class="col-sm-10">
                            <input type="text" placeholder="{{translate('Name En')}}" id="name" name="name_en"
                                   class="form-control" value="{{$city->name_en}}" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="shipping_cost">{{translate('Shipping Cost')}}</label>
                        <div class="col-sm-10">
                            <input type="text" placeholder="{{translate('Shipping Cost')}}" id="shipping_cost" name="shipping_cost"
                                   class="form-control" value="{{$city->shipping_cost}}" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="code">{{translate('Code')}}</label>
                        <div class="col-sm-10">
                            <input type="text" placeholder="{{translate('Code')}}" id="code" name="code"
                                   class="form-control" value="{{$city->code}}" required>
                        </div>
                    </div>
                    <div class="form-group" id="Country Name">
						<label class="col-sm-2 control-label">{{translate('Country Name')}}</label>
						<div class="col-sm-10">
							<select class="form-control demo-select2-placeholder" name="country_id" id="country_id" required>
								@foreach($countries as $country)
									<option {{( $city->country_id == $country->id)?'selected' : ''}} value="{{$country->id}}">{{ $country->name }}</option>
								@endforeach
							</select>
						</div>
					</div>
                   
                   
                    <div class="panel-footer text-right">
                        <button class="btn btn-purple" type="submit">{{translate('Save')}}</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection
