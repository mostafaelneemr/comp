@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-sm-12">
        <a href="{{ route('cities.create')}}" class="btn btn-rounded btn-info pull-right">{{translate('Add New city')}}</a>
    </div>
</div>

<br>
<div class="panel">
    <div class="panel-heading">
        <h3 class="panel-title">{{translate('city')}}</h3>
    </div>
    <div class="panel-body">
        <table class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th width="10%">#</th>
                    <th>{{translate('Country Name')}}</th>
                    <th>{{translate('Name')}}</th>
                    <th>{{translate('Code')}}</th>
                    <th>{{translate('Shipping Cost')}}</th>
                    <th>{{translate('Show/Hide')}}</th>
                    <th width="10%">{{translate('Options')}}</th>
                </tr>
            </thead>
            <tbody>
                @foreach($cities as $key => $city)
                    <tr>
                        <td>{{ $city->id }}</td>
                        <td>{{ $city->country->name }}</td>
                        <td>{{ $city->name }}</td>
                        <td>{{ $city->code }}</td>
                        <td>{{ $city->shipping_cost }}</td>
                        <td><label class="switch">
                                <input onchange="update_status(this)" value="{{ $city->id }}" type="checkbox" <?php if($city->status == 1) echo "checked";?> >
                                <span class="slider round"></span></label></td>
                        <td>
                            <div class="btn-group dropdown">
                                <button class="btn btn-primary dropdown-toggle dropdown-toggle-icon" data-toggle="dropdown" type="button">
                                    {{translate('Actions')}} <i class="dropdown-caret"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li><a href="{{route('cities.edit', encrypt($city->id))}}">{{translate('Edit')}}</a></li>
                                    <li><a onclick="confirm_modal('{{ route('cities.destroy',$city->id)}}');">{{translate('Delete')}}</a></li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
            <div class="clearfix">
                <div class="pull-right">
                    {{ $cities->links() }}
                </div>
            </div>
        </table>
        </div>
</div>
@endsection

@section('script')
    <script type="text/javascript">

        function update_status(el){
            if(el.checked){
                var status = 1;
            }
            else{
                var status = 0;
            }
            $.post('{{ route('cities.status') }}', {_token:'{{ csrf_token() }}', id:el.value, status:status}, function(data){
                if(data == 1){
                    showAlert('success', 'City status updated successfully');
                }
                else{
                    showAlert('danger', 'Something went wrong');
                }
            });
        }

    </script>
@endsection